﻿package ddd.simple.util;

public class Context {
	public static Object getSpringSession()
	{
		return null;
	}
	public static Object getDBSession()
	{
		return null;
	}	
	public static Object getStringUtil()
	{
		return null;
	}	
	public static Object getDateUtil()
	{
		return null;
	}	
	public static Object getNumberUtil()
	{
		return null;
	}	
	public static Object getJSONUtil()
	{
		return null;
	}	
	public static Object getFileUtil()
	{
		 // text file read and write 
		return null;
	}
	public static Object getImageUtil()
	{
		return null;
	}
}
